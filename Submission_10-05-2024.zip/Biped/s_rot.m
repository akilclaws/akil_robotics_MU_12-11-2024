function A = s_rot (local,t)
X = [-sin(t) -cos(t);cos(t) -sin(t)];
A = X*local;
end