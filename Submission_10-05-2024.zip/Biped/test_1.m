% Given vectors
r = [-0.1; 0.3; 0.25];
r_A = [0.977; 1.665; 2.916];
r_B = [-0.573;2.539;-0.709];

% Calculations
A = r_A - r;
B = r_B - r;

Mag_A = sqrt(A(1)^2 + A(2)^2 + A(3)^2);
Mag_B = sqrt(B(1)^2 + B(2)^2 + B(3)^2);

U_A = A / Mag_A;
U_B = B / Mag_B;

U_AxU_B = cross(U_A, U_B);

Check_1 = dot(U_A, U_B);
Check_2 = dot(U_B, U_AxU_B);

T = [U_A U_B U_AxU_B];
det_T = det(T);

trace_T = T(1, 1) + T(2, 2) + T(3, 3);

e0 = sqrt((trace_T + 1) / 4);
e1 = (T(3,2) - T(2,3))/(4*e0);
e2 = (T(1,3) - T(3,1))/(4*e0);
e3 = (T(2,1) - T(1,2))/(4*e0);

% e1 = sqrt((2 * T(1, 1) + 1 - trace_T) / 4);
% e2 = sqrt((2 * T(2, 2) + 1 - trace_T) / 4);
% e3 = sqrt((2 * T(3, 3) + 1 - trace_T) / 4);

% Plotting
figure;

% Plot points
scatter3([r(1), r_A(1), r_B(1), 0], [r(2), r_A(2), r_B(2), 0], [r(3), r_A(3), r_B(3), 0], 'o', 'LineWidth', 2);
hold on;

% Plot vectors
quiver3(r(1), r(2), r(3), A(1), A(2), A(3), 'r', 'LineWidth', 2, 'MaxHeadSize', 0.5);
quiver3(r(1), r(2), r(3), B(1), B(2), B(3), 'b', 'LineWidth', 2, 'MaxHeadSize', 0.5);

% Plot origin point
scatter3(0, 0, 0, 'k', 'filled', 'LineWidth', 2);

% Set axis labels
xlabel('X-axis');
ylabel('Y-axis');
zlabel('Z-axis');

% Set plot title
title('Vectors in 3D Space');

% Set legend
legend('Points (r, r_A, r_B, Origin)', 'Vector A (r_A - r)', 'Vector B (r_B - r)', 'Origin', 'Location', 'Best');

% Show grid
grid on;

% Show quaternion components
disp('Quaternion components:');
disp(['e0: ', num2str(e0)]);
disp(['e1: ', num2str(e1)]);
disp(['e2: ', num2str(e2)]);
disp(['e3: ', num2str(e3)]);
