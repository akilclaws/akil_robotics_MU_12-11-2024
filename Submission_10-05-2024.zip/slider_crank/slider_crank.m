function [Mj,C,G,Tr] = slider_crank(Tm,Mm,Lm,thetam,theta_dm)

g = 9.81;

Tr = [Tm(1,2) - Tm(1,1) + Tm(1,3); Tm(1,3); 0];

G = [Mm(2,1)*g*(Lm(1,1)*cos(thetam(1,1)) + (Lm(2,1)*cos(thetam(1,2)))/2) + (Lm(1,1)*Mm(1,1)*g*cos(thetam(1,1)))/2; (Lm(2,1)*Mm(2,1)*g*cos(thetam(1,2)))/2; -Mm(3,1)*g*sin(thetam(1,3))];

ha = [0; -Mm(1,1)*g; 0; 0; -Mm(2,1)*g; 0; 0; -Mm(3,1)*g; 0];

ht = [0; 0; Tm(1,2) - Tm(1,1); 0; 0; Tm(1,3); 0; 0; Tm(1,4)];

C = [Mm(2,1)*(Lm(1,1)*cos(thetam(1,1)) + (Lm(2,1)*cos(thetam(1,2)))/2)*(Lm(1,1)*theta_dm(1,1)*sin(thetam(1,1)) + (Lm(2,1)*theta_dm(1,2)*sin(thetam(1,2)))/2) - Mm(2,1)*(Lm(1,1)*theta_dm(1,1)*cos(thetam(1,1)) + (Lm(2,1)*theta_dm(1,2)*cos(thetam(1,2)))/2)*(Lm(1,1)*sin(thetam(1,1)) + (Lm(2,1)*sin(thetam(1,2)))/2), (Lm(2,1)*Mm(2,1)*theta_dm(1,2)*sin(thetam(1,2))*(Lm(1,1)*cos(thetam(1,1)) + (Lm(2,1)*cos(thetam(1,2)))/2))/2 - (Lm(2,1)*Mm(2,1)*theta_dm(1,2)*cos(thetam(1,2))*(Lm(1,1)*sin(thetam(1,1)) + (Lm(2,1)*sin(thetam(1,2)))/2))/2, 0; (Lm(2,1)*Mm(2,1)*cos(thetam(1,2))*(Lm(1,1)*theta_dm(1,1)*sin(thetam(1,1)) + (Lm(2,1)*theta_dm(1,2)*sin(thetam(1,2)))/2))/2 - (Lm(2,1)*Mm(2,1)*sin(thetam(1,2))*(Lm(1,1)*theta_dm(1,1)*cos(thetam(1,1)) + (Lm(2,1)*theta_dm(1,2)*cos(thetam(1,2)))/2))/2, 0, 0; 0, 0, Mm(3,1)*cos(thetam(1,3))^2 + Mm(3,1)*sin(thetam(1,3))^2];

Mj = [(Lm(1,1)^2*Mm(1,1))/12 + (Lm(2,1)^2*Mm(2,1))/12 + Mm(2,1)*(Lm(1,1)*cos(thetam(1,1)) + (Lm(2,1)*cos(thetam(1,2)))/2)^2 + Mm(2,1)*(Lm(1,1)*sin(thetam(1,1)) + (Lm(2,1)*sin(thetam(1,2)))/2)^2 + (Lm(1,1)^2*Mm(1,1)*cos(thetam(1,1))^2)/4 + (Lm(1,1)^2*Mm(1,1)*sin(thetam(1,1))^2)/4, (Lm(2,1)^2*Mm(2,1))/12 + (Lm(2,1)*Mm(2,1)*cos(thetam(1,2))*(Lm(1,1)*cos(thetam(1,1)) + (Lm(2,1)*cos(thetam(1,2)))/2))/2 + (Lm(2,1)*Mm(2,1)*sin(thetam(1,2))*(Lm(1,1)*sin(thetam(1,1)) + (Lm(2,1)*sin(thetam(1,2)))/2))/2, 0; (Lm(2,1)^2*Mm(2,1))/12 + (Lm(2,1)*Mm(2,1)*cos(thetam(1,2))*(Lm(1,1)*cos(thetam(1,1)) + (Lm(2,1)*cos(thetam(1,2)))/2))/2 + (Lm(2,1)*Mm(2,1)*sin(thetam(1,2))*(Lm(1,1)*sin(thetam(1,1)) + (Lm(2,1)*sin(thetam(1,2)))/2))/2, (Lm(2,1)^2*Mm(2,1))/12 + (Lm(2,1)^2*Mm(2,1)*cos(thetam(1,2))^2)/4 + (Lm(2,1)^2*Mm(2,1)*sin(thetam(1,2))^2)/4, 0; 0, 0, Mm(3,1)*cos(thetam(1,3))^2 + Mm(3,1)*sin(thetam(1,3))^2];

B = [-(Lm(1,1)*sin(thetam(1,1)))/2, 0, 0; (Lm(1,1)*cos(thetam(1,1)))/2, 0, 0; 1, 0, 0; - Lm(1,1)*sin(thetam(1,1)) - (Lm(2,1)*sin(thetam(1,2)))/2, -(Lm(2,1)*sin(thetam(1,2)))/2, 0; Lm(1,1)*cos(thetam(1,1)) + (Lm(2,1)*cos(thetam(1,2)))/2, (Lm(2,1)*cos(thetam(1,2)))/2, 0; 1, 1, 0; 0, 0, -cos(thetam(1,3)); 0, 0, -sin(thetam(1,3)); 0, 0, 0];

B_d = [(Lm(1,1)*theta_dm(1,1)*cos(thetam(1,1)))/2, 0, 0; (Lm(1,1)*theta_dm(1,1)*sin(thetam(1,1)))/2, 0, 0; 0, 0, 0; Lm(1,1)*theta_dm(1,1)*cos(thetam(1,1)) + (Lm(2,1)*theta_dm(1,2)*cos(thetam(1,2)))/2, (Lm(2,1)*theta_dm(1,2)*cos(thetam(1,2)))/2, 0; Lm(1,1)*theta_dm(1,1)*sin(thetam(1,1)) + (Lm(2,1)*theta_dm(1,2)*sin(thetam(1,2)))/2, (Lm(2,1)*theta_dm(1,2)*sin(thetam(1,2)))/2, 0; 0, 0, 0; 0, 0, -cos(thetam(1,3)); 0, 0, -sin(thetam(1,3)); 0, 0, 0];

end