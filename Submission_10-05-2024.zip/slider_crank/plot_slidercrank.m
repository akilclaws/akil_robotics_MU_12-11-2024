clc;
clear all;

xspan = 0:0.1:5; % Reduce the step size for smoother animation1

% Initial conditions
theta_1 = pi/2; % Initial angle in degrees
theta_2 = 0;
theta_3 = 0;
theta1_d = 0; % Initial angular velocity
theta2_d = 0;
theta3_d = 0;
y0 = [theta_1,theta_2,theta_3,theta1_d,theta2_d,theta3_d]; % Initial state vector

% Solve the differential equation
[x, y] = ode45(@(x, y) Solver_1(x, y), xspan, y0);

% Extracting the joint angle
theta = y(:, 1);

% Define the link length
L1 = 1;

% Plot initial configuration
figure;
hold on;
axis equal;
grid on;
xlim([-1.5*L1, 1.5*L1]);
ylim([-1.5*L1, 1.5*L1]);

% Update the plot for each time step to create animation
for i = 1:length(x)
    pause(0.1);
    % Plotting results
subplot(2,3,1)
plot(x, y(:,1), 'b')
title('Angular displacement_1 vs Time')
xlabel('Time (s)')
ylabel('Angle (rad)')

subplot(2,3,2)
plot(x, y(:,2), 'b')
title('Angular displacement_2 vs Time')
xlabel('Time (s)')
ylabel('Angle (rad)')

subplot(2,3,3)
plot(x, y(:,3), 'b')
title('Angular displacement_3 vs Time')
xlabel('Time (s)')
ylabel('Angle (rad)')

subplot(2,3,4)
plot(x, y(:,4), 'r')
title('Angular velocity_1 vs Time')
xlabel('Time (s)')
ylabel('Angular Velocity (rad/s)')

subplot(2,3,5)
plot(x, y(:,5), 'r')
title('Angular velocity_2 vs Time')
xlabel('Time (s)')
ylabel('Angular Velocity (rad/s)')

subplot(2,3,6)
plot(x, y(:,6), 'r')
title('Angular velocity_3 vs Time')
xlabel('Time (s)')
ylabel('Angular Velocity (rad/s)')
end

function val = Solver_1(x, y0)
    theta_1 = y0(1);
    theta_2 = y0(2);
    theta_3 = y0(3);
    theta1_d = y0(4);
    theta2_d = y0(5);
    theta3_d = y0(6);

    L1 = 1;     L2 = 1;     L3 = 1;
    Lm = [L1;L2;L3];
    M1 = 2;     M2 = 2;     M3 = 2;
    Mm = [M1;M2;M3];
    T0 = 0;     T1 = 0;     T2 = 0;     T3 = 0;
    Tm = [T0 T1 T2 T3];
    g=9.81;
    thetam = [theta_1 theta_2 theta_3];
    theta_dm = [theta1_d theta2_d theta3_d];
    [Mj,C,G,T] = slider_crank(Tm,Mm,Lm,thetam,theta_dm);

    q_dd = (T - (C * theta1_d) - (G ))/(Mj);
    
    val(1, 1) = theta1_d;
    val(2, 1) = theta2_d;
    val(3, 1) = theta3_d;
    val(4, 1) = q_dd(1, 1);
    val(5, 1) = q_dd(2, 1);
    val(6, 1) = q_dd(3, 1);
end
