%% Code for Slider Crank 
clc;
clear all;

syms L1 L2 B theta_1 theta_2 theta_3 theta1_d theta2_d M1 M2 M3 T1 T0 T2 T3 g real

s_O1 = [-L1/2;0];                               % local Matrix
s_A1 = [L1/2;0];                
s_A2 = [-L2/2;0];

A_1 = f_rotate(theta_1);                        % Rotation matrix
A_2 = f_rotate(theta_2);

S_O1 = A_1*s_O1;                                % Global matrix of s_A1
S_A1 = A_1*s_A1;    
S_A2 = A_2*s_A2;

S_O1r = s_rot (s_O1,theta_1);                           % Global rotational matix of s_A1
S_A1r = s_rot (s_A1,theta_1);
S_A2r = s_rot (s_A2,theta_2);

J1 = M1*(L1)^2/12;                              % mass moment of inertia
J2 = M2*(L2^2)/12;
J3 = M3*(B^3)/12;

M_diag = [M1 M1 J1 M2 M2 J2 M3 M3 J3]';         % mass matrix
M = diag(M_diag);

u3 = [cos(theta_3);sin(theta_3)];
I2 = eye(2);
Z2 = zeros(2);
Z12 = zeros(1,2);
Z21 = zeros(2,1);

d11 = -S_O1r;
d21 = -S_O1r+S_A1r-S_A2r;
d22 = -S_A2r;

d11_d = -S_O1*theta1_d;
d21_d = (-S_O1+S_A1)*theta1_d-(S_A2*theta2_d);
d22_d = -S_A2*theta2_d;

B = [d11 Z2;                                         % B matix   
    1 0 0;
    d21 d22 Z21;
    1 1 0;
    Z2 -u3;
    0 0 0];  

ha = [0;-M1*g;0;0;-M2*g;0;0;-M3*g;0];               % Actual forces
ht = [0;0;T1-T0;0;0;T2;0;0;T3];                     % Actual torque

B_d = [d11_d Z2;
       0 0 0;
       d21_d d22_d Z21;
       0 0 0;
       Z2 -u3;
       0 0 0];        % B_dot matrix

Mj = B'*M*B;        % inertia term
C = B'*M*B_d;       % corollis acceleration
G = -B'*ha;         % gravity term
Tr=B'*ht;           % twisting moment
% Open a new file
fid = fopen('slider.txt', 'w'); % 'w' for write mode

% Write the values of the variables into the file
fprintf(fid, 'Tr = ');
fprintf(fid, '%s\n', char(Tr));
fprintf(fid, '\n');

fprintf(fid, 'G = ');
fprintf(fid, '%s\n', char(G));
fprintf(fid, '\n');

fprintf(fid, 'ha = ');
fprintf(fid, '%s\n', char(ha));
fprintf(fid, '\n');

fprintf(fid, 'ht = ');
fprintf(fid, '%s\n', char(ht));
fprintf(fid, '\n');

fprintf(fid, 'C = ');
fprintf(fid, '%s\n', char(C));
fprintf(fid, '\n');

fprintf(fid, 'Mj = ');
fprintf(fid, '%s\n', char(Mj));
fprintf(fid, '\n');

fprintf(fid, 'B = ');
fprintf(fid, '%s\n', char(B));
fprintf(fid, '\n');

fprintf(fid, 'B_d = ');
fprintf(fid, '%s\n', char(B_d));
fprintf(fid, '\n');

% Close the file
fclose(fid);