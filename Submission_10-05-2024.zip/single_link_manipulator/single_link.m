function [Mj,C,G,Tr] = single_link(T1,M1,g,L1,theta_1,theta1_d)

Tr = -T1;

G = (L1*M1*g*cos(theta_1))/2;

ha = [0; -M1*g; 0];

ht = [0; 0; -T1];

C = 0;

Mj = (L1^2*M1)/12 + (L1^2*M1*cos(theta_1)^2)/4 + (L1^2*M1*sin(theta_1)^2)/4;

B = [-(L1*sin(theta_1))/2; (L1*cos(theta_1))/2; 1];

B_d = [-(L1*theta1_d*cos(theta_1))/2; -(L1*theta1_d*sin(theta_1))/2; 0];

end