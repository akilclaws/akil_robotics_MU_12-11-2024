%% Code for Single link Manipulator 

clc;
clear all;

syms L1 theta_1 theta1_d M1 T1 T0 g real

s_A1 = [-L1/2;0];                % local Matrix
A = f_rotate(theta_1);          % Rotation matrix

S_A1 = A*s_A1;                  % Global matrix of s_A1
S_A1r = s_rot (s_A1,theta_1);           % Global rotational matix of s_A1

J1 = M1*(L1^2)/12;              % mass moment of inertia
M = [M1 0 0;0 M1 0;0 0 J1];     % mass matrix

d11 = -S_A1r;
d11_d = -S_A1*theta1_d;

B = [d11; 1];                % B matix
B_d = [-d11_d;0];        % B_dot matrix

ha = [0;-M1*g;0];               % Actual forces
ht = [0;0;-T1];               % Actual torque

Mj = B'*M*B;        % inertia term
C = B'*M*B_d;       % corollis acceleration
G = -B'*ha;        % gravity term
Tr=B'*ht;          % torque
% Open a new file
fid = fopen('one_link.txt', 'w'); % 'w' for write mode

% Write the values of the variables into the file
fprintf(fid, 'Tr = ');
fprintf(fid, '%s\n', char(Tr));
fprintf(fid, '\n');

fprintf(fid, 'G = ');
fprintf(fid, '%s\n', char(G));
fprintf(fid, '\n');

fprintf(fid, 'ha = ');
fprintf(fid, '%s\n', char(ha));
fprintf(fid, '\n');

fprintf(fid, 'ht = ');
fprintf(fid, '%s\n', char(ht));
fprintf(fid, '\n');

fprintf(fid, 'C = ');
fprintf(fid, '%s\n', char(C));
fprintf(fid, '\n');

fprintf(fid, 'Mj = ');
fprintf(fid, '%s\n', char(Mj));
fprintf(fid, '\n');

fprintf(fid, 'B = ');
fprintf(fid, '%s\n', char(B));
fprintf(fid, '\n');

fprintf(fid, 'B_d = ');
fprintf(fid, '%s\n', char(B_d));
fprintf(fid, '\n');

% Close the file
fclose(fid);