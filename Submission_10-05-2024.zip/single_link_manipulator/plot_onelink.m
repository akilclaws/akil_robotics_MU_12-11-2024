clc;
clear all;

xspan = 0:0.1:2; % Reduce the step size for smoother animation1

% Initial conditions
theta_1 = pi; % Initial angle in degrees
theta1_d = 0; % Initial angular velocity
y0 = [theta_1, theta1_d]; % Initial state vector

% Solve the differential equation
[x, y] = ode45(@(x, y) Solver_1(x, y), xspan, y0);

% Extracting the joint angle
theta = y(:, 1);

% Define the link length
L1 = 1;

% Plot initial configuration
figure;
hold on;
axis equal;
grid on;
xlim([-1.5*L1, 1.5*L1]);
ylim([-1.5*L1, 1.5*L1]);

% Update the plot for each time step to create animation
for i = 1:length(x)
    pause(0.1);
    % Plotting results
subplot(2,1,1)
plot(x, y(:,1), 'b')
title('Angular displacement vs Time')
xlabel('Time (s)')
ylabel('Angle (rad)')

subplot(2,1,2)
plot(x, y(:,2), 'r')
title('Angular velocity vs Time')
xlabel('Time (s)')
ylabel('Angular Velocity (rad/s)')
end

function val = Solver_1(x, y0)
    theta_1 = y0(1);
    theta1_d = y0(2);
    L1 = 1;
    M1 = 2;
    T1 = 0;
    T0 = 0;
    g = 9.81;

    [Mj,C,G,Tr] = single_link(T1,M1,g,L1,theta_1,theta1_d);
    q_dd = (Tr - (C * theta1_d) - (G ))/(Mj);

    val(1, 1) = theta1_d;
    val(2, 1) = q_dd;
end
