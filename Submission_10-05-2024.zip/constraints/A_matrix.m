function [Ai,Aj] = A_matrix(e0i,e0j,ei,ej,ei_tilda,ej_tilda)

I = eye (3);
Ai = (2*(e0i*e0i)-1)*I + 2*((ei*ei')+e0i*ei_tilda);
Aj = (2*(e0j*e0j)-1)*I + 2*((ej*ej')+e0j*ej_tilda);

end