function [Si_d,Sj_d] = SG_d(Gi,siL_minus,dpi,Gj,sjL_minus,dpj)
Si_d = 2*Gi*siL_minus*dpi;
Sj_d = 2*Gj*sjL_minus*dpj;
end