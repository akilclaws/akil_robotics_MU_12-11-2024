% parallel constraint
clc
clear all

syms e0i e1i e2i e3i e0_di e1_di e2_di e3_di ...
     e0j e1j e2j e3j e0_dj e1_dj e2_dj e3_dj ...
     sLi_1 sLi_2 sLi_3 ...
     sLj_1 sLj_2 sLj_3 ...

I = eye (3);

ei = [e1i;e2i;e3i];
ej = [e1j;e2j;e3j];
pi = [e0i;e1i;e2i;e3i];
dpi =[e0_di;e1_di;e2_di;e3_di];
pj = [e0j;e1j;e2j;e3j];
dpj =[e0_dj;e1_dj;e2_dj;e3_dj];

sLi = [sLi_1;sLi_2;sLi_3];
sLj = [sLj_1;sLj_2;sLj_3];

[ei_tilda,ej_tilda] = e_tilda(ei,ej);       % e_tilda function

[Gi,G_di,Li,L_di] = Gm_Lm (pi,dpi);         % G & L matrix function
[Gj,G_dj,Lj,L_dj] = Gm_Lm (pj,dpj);

[sLi_tilda,sLj_tilda] = sL_tilda(sLi,sLj);

[Ai,Aj] = A_matrix(e0i,e0j,ei,ej,ei_tilda,ej_tilda);    % A_matix function

[Si_tilda,Sj_tilda] = SG_tilda(Ai,sLi_tilda,Aj,sLj_tilda);      % Global tilda function

[siL_minus,sjL_minus] = sL_minus(sLi,sLi_tilda,sLj,sLj_tilda);   % local minus/attr matrix

[hi,hj] = h(G_di,L_di,sLi,G_dj,L_dj,sLj);                       % h_matrix function

[Si_d,Sj_d] = SG_d(Gi,siL_minus,dpi,Gj,sjL_minus,dpj);

[Si_d_tilda,Sj_d_tilda] = S_d_tilda(Si_d,Sj_d);                 % S_d function 

Jacobian = [zeros(3), -2*Sj_tilda*Gi*siL_minus,zeros(3), 2*Si_tilda*Gj*sjL_minus];

Gamma = (Si_tilda * hj)-(Sj_tilda*hi)-(2*Si_d_tilda*Sj_d);