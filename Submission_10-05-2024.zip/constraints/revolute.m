clc
clear all

Jacobian = [eye(3), 2*Gi*siL_minus,-eye(3),-2*Gj*sjL_minus; ...
            zeros(3), -2*Sj_tilda*Gi*siL_minus,zeros(3), 2*Si_tilda*Gj*sjL_minus];

Gamma = (Si_tilda * hj)-(Sj_tilda*hi)-(2*Si_d_tilda*Sj_d)+hi - hj;