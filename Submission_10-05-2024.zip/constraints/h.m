function [hi,hj] = h(G_di,L_di,sLi,G_dj,L_dj,sLj)
hi = -2*G_di*L_di'*sLi;
hj = -2*G_dj*L_dj'*sLj;
end