clc
clear all

sL_P1 = [-1;0;0];
sL_P2 = [1;0;0];

sL_S1 = [0;1;0];
sL_S2 = [0;1;0];

sL_a1 = [0;-1;0];
sL_a2 = [0;-1;0];

joint = 'spherical';
[Jacobian_S,Gamma_S] = constraints(joint,sL_S1,sL_S2);

Jacobian_S_a = Jacobian_S(:, end-6:end);
size(Jacobian_S_a)

joint = 'parallel';
[Jacobian_P,Gamma_P] = constraints(joint,sL_P1,sL_P2);

Jacobian_P_a = Jacobian_P(1:2, end-6:end);
size(Jacobian_P_a)

joint = 'spherical_to_revolute';
[Jacobian_S_P] = constraints(joint,sL_a1,sL_a2);

Jacobian_S_P_a = Jacobian_S_P(1:2,:);
size(Jacobian_S_P_a)

Jacobian = [Jacobian_S_a;
            Jacobian_P_a;
            Jacobian_S_P_a];
size(Jacobian)

disp(Jacobian_S_a)
disp(Jacobian_P_a)
disp(Jacobian_S_P_a)

det(Jacobian)

syms r theta theta_d

Right_side = [zeros(3,1);zeros(2,1);0;r*cos(theta)*theta_d];
size(Right_side);
x_eulers = inv(Jacobian)*Right_side

% solve ODE and Eqautions get theta & theta_d