function [siL_minus,sjL_minus] = sL_minus(sLi,sLi_tilda,sLj,sLj_tilda)
siL_minus = [0 -sLi';
             sLi -sLi_tilda];
sjL_minus = [0 -sLj';
             sLj -sLj_tilda];
end