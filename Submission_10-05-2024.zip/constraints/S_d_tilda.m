function [Si_d_tilda,Sj_d_tilda] = S_d_tilda(Si_d,Sj_d)
Si_d_tilda = [0       -Si_d(3,1)    Si_d(2,1);
           Si_d(3,1)     0      -Si_d(1,1);
          -Si_d(2,1)   Si_d(1,1)       0  ];

Sj_d_tilda = [0       -Sj_d(3,1)    Sj_d(2,1);
           Sj_d(3,1)     0      -Sj_d(1,1);
          -Sj_d(2,1)   Sj_d(1,1)       0  ];
end