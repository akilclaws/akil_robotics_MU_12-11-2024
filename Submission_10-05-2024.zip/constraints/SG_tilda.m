function [Si_tilda,Sj_tilda] = SG_tilda(Ai,sLi_tilda,Aj,sLj_tilda)
Si_tilda = Ai*sLi_tilda*Ai';
Sj_tilda = Aj*sLj_tilda*Aj';
end