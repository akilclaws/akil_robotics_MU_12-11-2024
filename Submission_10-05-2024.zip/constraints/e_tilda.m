function [ei_tilda,ej_tilda] = e_tilda(ei,ej) 

ei_tilda = [0       -ei(3,1)    ei(2,1);
           ei(3,1)     0      -ei(1,1);
          -ei(2,1)   ei(1,1)       0  ];

ej_tilda = [0       -ej(3,1)    ej(2,1);
           ej(3,1)     0      -ej(1,1);
          -ej(2,1)   ej(1,1)       0  ];
end
