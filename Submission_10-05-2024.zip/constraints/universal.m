clc
clear all

Jacobian = [zeros(1), 2*Sj'*Gi*siL_minus, zeros(1), 2*Si'*Gj*sjL_minus; ...
            eye(3), 2*Gi*siL_minus, -eye(3),-2*Gj*sjL_minus];

Gamma = (Si * hj')+(Sj'*hi)-(2*Si_d'*Sj_d)+hi - hj;