function [sLi_tilda,sLj_tilda] = sL_tilda(sLi,sLj)

sLi_tilda = [0       -sLi(3,1)    sLi(2,1);
           sLi(3,1)     0      -sLi(1,1);
          -sLi(2,1)   sLi(1,1)       0  ];

sLj_tilda = [0       -sLj(3,1)    sLj(2,1);
           sLj(3,1)     0      -sLj(1,1);
          -sLj(2,1)   sLj(1,1)       0  ];
end