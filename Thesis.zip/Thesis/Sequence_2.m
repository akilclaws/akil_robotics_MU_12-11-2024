clc;
clear;
close all;

%% Normalizing with max of MVC to that of EMG
% 1. MVC_to_EMG
%     * first select MVC file
%     * second select EMG file 
%     * Type Name of the output file in Normalized data

[Normalized_EMG_Flexion,Normalized_EMG_Extension] = MVC_to_EMG();

%% Filtering data
% 1. select EMG file that is Normalized
% 2. select Encoder data

siddharth_filter();

%% Labelling as Flexion, Extension, Rest

% 3. Based on slope Increasing slope --> Flexion
                    % Decreasing slope --> Extension
                    % slope 0 --> Rest
          % * Select interpolated_encoder_data 
          % * Save the data in Labelled data

Labelling_1();

%% Append dataset

% 4. Combine all the dataset to be used
            % * change the Names of dataset to be included

Append_dataset();

%% Have to get the features

