function Labelling_1()

% Open the folder for selecting the input Excel sheet with the 'Angle' column
input_folder = 'C:\Users\AKILAN\Downloads\EMG_DATA\Interpolated_data';
[input_file, input_path] = uigetfile(fullfile(input_folder, '*.xlsx'), 'Select the Excel File Containing Angle Column');
input_file_fullpath = fullfile(input_path, input_file);

% Load the data from the selected Excel sheet
data = readtable(input_file_fullpath);  % Read the Excel file as a table
angle_data = data.Angle;  % Extract the 'Angle' column

% Preallocate array for labels
labels = strings(length(angle_data), 1);

% Calculate the slope between consecutive points
slope = diff(angle_data);

% Iterate through slope and assign labels
for i = 1:length(slope)
    if slope(i) > 0
        labels(i) = 'Flexion';  % Rising slope
    elseif slope(i) < 0
        labels(i) = 'Extension';  % Decreasing slope
    else
        labels(i) = 'Rest';  % Zero slope
    end
end

% Add a 'Rest' label for the last point since diff reduces size by 1
labels(end) = 'Rest';

% Add the labels to the original table
data.Labels = labels;  % Ensure labels and data have the same length

% Save the updated table with labels to a new Excel file
[output_file, output_path] = uiputfile('*.xlsx', 'Save the Labeled Data As');
output_fullpath = fullfile(output_path, output_file);
writetable(data, output_fullpath);

disp('Data with labels has been written to the selected Excel file.');
end