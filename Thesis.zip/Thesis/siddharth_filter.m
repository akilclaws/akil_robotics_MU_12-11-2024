function siddharth_filter()
% Prompt the user to select an Excel file
[filename, pathname] = uigetfile('*.csv', 'Select the EMG file');
if isequal(filename, 0)
    disp('User selected Cancel');
    return; % Exit the program if no file is selected
else
    disp(['User selected ', fullfile(pathname, filename)]);
    fullpath = fullfile(pathname, filename);
end

% Load data from the selected Excel file
data = readmatrix(fullpath); % Read the entire data from the selected Excel file

% Assuming flexion data is in column 1, extension data is in column 2
selected_data_flexion = data(:, 1); % Extract flexion data (Biceps)
selected_data_extension = data(:, 2); % Extract extension data (Triceps)

% Remove mean from the signals
selected_data_flexion_1 = selected_data_flexion; %- mean(selected_data_flexion);
selected_data_extension_1 = selected_data_extension; %- mean(selected_data_extension);

%% Interpolation of Encoder Data
% Prompt the user to select an Encoder data file (Excel)
[encoder_file, encoder_path] = uigetfile('*.xlsx', 'Select the Encoder Data File');
if isequal(encoder_file, 0)
    disp('User selected Cancel');
    return; % Exit the program if no file is selected
else
    encoder_fullpath = fullfile(encoder_path, encoder_file);
end

% Read Encoder data from the selected Excel file
encoder_data = readtable(encoder_fullpath);

% Assuming Encoder data is in a column named 'Angle'
original_encoder_data = encoder_data.Angle; % Adjust column name if different

% Create a new time vector for the EMG data
num_emg_data_points = length(selected_data_flexion_1); % Length of EMG data
new_time_vector = linspace(1, length(original_encoder_data), num_emg_data_points);

% Interpolate Encoder data to match the length of the EMG data
interpolated_encoder_data = interp1(1:length(original_encoder_data), original_encoder_data, new_time_vector);
interpolated_encoder_data = interpolated_encoder_data * (pi/180);

%% FFT (Fast Fourier Transform)
fs = 1000; % Sampling frequency (Assuming a specific sampling frequency in Hz)
L = numel(selected_data_flexion_1); % Length of the signal
f = fs * (0:(L/2)) / L; % Frequency vector
t = (0:L-1) * (1/fs); % Time vector

% FFT for flexion
p1 = fft(selected_data_flexion_1);
p1 = abs(p1/L);
p1 = p1(1:L/2 + 1);
p1(2:end-1) = 2*p1(2:end-1);

% FFT for extension
p2 = fft(selected_data_extension_1);
p2 = abs(p2/L);
p2 = p2(1:L/2 + 1);
p2(2:end-1) = 2*p2(2:end-1);

% Plot FFT results
figure;
subplot(2,1,1);
plot(f, p1);
xlabel('Frequency (Hz)');
ylabel('Intensity');
title('Biceps FFT');
grid on;

subplot(2,1,2);
plot(f, p2);
xlabel('Frequency (Hz)');
ylabel('Intensity');
title('Triceps FFT');
grid on;

%% Bandpass Filter (30 to 300 Hz)
fnyq = fs/2; % Nyquist frequency
fcuthigh = 30; % Highpass cutoff frequency in Hz
fcutlow = 400; % Lowpass cutoff frequency in Hz

% 4th order Butterworth bandpass filter
[b, a] = butter(4, [fcuthigh, fcutlow] / fnyq, 'bandpass');

% Apply bandpass filter to the data
selected_data_flexion_1 = filtfilt(b, a, selected_data_flexion_1);
selected_data_extension_1 = filtfilt(b, a, selected_data_extension_1);

%% Full-wave Rectification
rec_signal_flexion_1 = abs(selected_data_flexion_1);
rec_signal_extension_1 = abs(selected_data_extension_1);

% Plot the filtered and rectified signals
figure;
subplot(2, 1, 1);
plot(t, rec_signal_flexion_1);
xlabel('Time (seconds)');
ylabel('Voltage');
title('Biceps EMG with Bandpass Filter and Rectification');
grid on;

subplot(2, 1, 2);
plot(t, rec_signal_extension_1);
xlabel('Time (seconds)');
ylabel('Voltage');
title('Triceps EMG with Bandpass Filter and Rectification');
grid on;

%% RMS Envelope (Moving Average)
window = 75; % Window size in ms

% Calculate RMS envelope
envelope_flexion_1 = sqrt(movmean(rec_signal_flexion_1.^2, window));
envelope_extension_1 = sqrt(movmean(rec_signal_extension_1.^2, window));

% Plot rectified signals and their envelopes
figure;
subplot(3, 1, 1);
%plot(t, rec_signal_flexion_1);
hold on;
plot(t, envelope_flexion_1, 'r', 'LineWidth', 1.5);
xlabel('Time (seconds)');
ylabel('Voltage');
title('Enveloping of Biceps EMG');
grid on;

subplot(3, 1, 2);
%plot(t, rec_signal_extension_1);
hold on;
plot(t, envelope_extension_1, 'g', 'LineWidth', 1.5);
xlabel('Time (seconds)');
ylabel('Voltage');
title('Enveloping of Triceps EMG');
grid on;

% Compare flexion and extension envelopes
subplot(3, 1, 3);
plot(t, envelope_flexion_1, 'r', t, envelope_extension_1, 'g');
xlabel('Time (seconds)');
ylabel('Voltage');
title('Comparison of EMG Signals');
legend('Flexion', 'Extension');
grid on;

figure;
plot(t, envelope_flexion_1, 'r', t, envelope_extension_1, 'b', t, interpolated_encoder_data,'g','LineWidth', 1.5);
% plot(t, envelope_flexion_1, 'r', t, envelope_extension_1, 'b','LineWidth', 1.5);
xlabel('Time (seconds)');
ylabel('Voltage');
title('Comparison of EMG Signals');
legend('Flexion', 'Extension');
grid on;
%% Store results in an Excel file

% Set the path for saving the output Excel file
output_path = 'C:\Users\AKILAN\Downloads\EMG_DATA\processed_data\Processed_EMG_Data_sridhar.xlsx'; % Change this path as needed

% Prepare data for writing to Excel
output_data_time_domain = [t', selected_data_flexion_1, selected_data_extension_1, rec_signal_flexion_1, rec_signal_extension_1, envelope_flexion_1, envelope_extension_1];
output_data_fft = [f', p1, p2]; % Frequency and FFT values

% Define column headers
headers_time_domain = {'Time', 'Flexion_Average_to_Zero', 'Extension__Average_to_Zero', 'Flexion_Rectified', 'Extension_Rectified', 'Flexion_Envelope', 'Extension_Envelope'};
headers_fft = {'Frequency (Hz)', 'Flexion_FFT', 'Extension_FFT'};

% Write headers and time domain data to Excel file
writecell(headers_time_domain, output_path, 'Sheet', 1, 'Range', 'A1');
writematrix(output_data_time_domain, output_path, 'Sheet', 1, 'Range', 'A2');

% Write FFT headers and data to a second sheet in the Excel file
writecell(headers_fft, output_path, 'Sheet', 2, 'Range', 'A1');
writematrix(output_data_fft, output_path, 'Sheet', 2, 'Range', 'A2');

disp(['Processed data including FFT values has been saved to: ', output_path]);

end