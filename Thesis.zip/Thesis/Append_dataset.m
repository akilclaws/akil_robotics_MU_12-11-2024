function Append_dataset()

% Define file paths for the three input Excel sheets
file1 = 'C:\Users\AKILAN\Downloads\EMG_DATA\Normalized & Labelled\Deep.xlsx';
file2 = 'C:\Users\AKILAN\Downloads\EMG_DATA\Normalized & Labelled\Akilan.xlsx';
file3 = 'C:\Users\AKILAN\Downloads\EMG_DATA\Normalized & Labelled\Sumit.xlsx';
file4 = 'C:\Users\AKILAN\Downloads\EMG_DATA\Normalized & Labelled\Prajakta.xlsx';
file5 = 'C:\Users\AKILAN\Downloads\EMG_DATA\Normalized & Labelled\Trishala.xlsx';
file6 = 'C:\Users\AKILAN\Downloads\EMG_DATA\Normalized & Labelled\Subbhu.xlsx';

% Read data from each file while skipping the first row
data1 = readtable(file1, 'Range', 'A2'); % Reads data starting from the second row
data2 = readtable(file2, 'Range', 'A2'); % Reads data starting from the second row
data3 = readtable(file3, 'Range', 'A2'); % Reads data starting from the second row
data4 = readtable(file4, 'Range', 'A2'); % Reads data starting from the second row
data5 = readtable(file5, 'Range', 'A2'); % Reads data starting from the second row
data6 = readtable(file6, 'Range', 'A2'); % Reads data starting from the second row

% Combine the data from all three sheets
% combinedData = [data3];  
combinedData = [data1; data2; data3; data4; data5; data6];

% Define the output file path
outputFile = 'C:\Users\AKILAN\Downloads\EMG_DATA\Appended_dataset\dataset.xlsx';

% Write the combined data to the output Excel file
writetable(combinedData, outputFile);

disp('Data from all sheets has been combined and saved to the output file.');
end