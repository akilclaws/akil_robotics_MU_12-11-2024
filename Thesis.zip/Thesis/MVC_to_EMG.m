function [Normalized_EMG_Flexion,Normalized_EMG_Extension] = MVC_to_EMG()

% Set default folder
%defaultFolder = 'C:\Users\AKILAN\Downloads\EMG_DATA\Dataset';

defaultFolder = 'C:\Users\AKILAN\Downloads\AT_SensorData';

% Pop-up to select the MVC data file with default folder
[MVCfileName, MVCfilePath] = uigetfile(fullfile(defaultFolder, '*.csv'), 'Select the MVC Data Excel File');
MVCfile = fullfile(MVCfilePath, MVCfileName);

% Read the MVC data
mvcData = readtable(MVCfile);

% Extract the EMG_Flexion and EMG_Extension columns
mvcFlexion = mvcData.EMG_Flexion;
mvcExtension = mvcData.EMG_Extension;

% Find the maximum values for Flexion and Extension
maxMVCFlexion = max(mvcFlexion);
maxMVCExtension = max(mvcExtension);

% Pop-up to select the EMG data file with default folder
[EMGfileName, EMGfilePath] = uigetfile(fullfile(defaultFolder, '*.csv'), 'Select the EMG Data Excel File');
EMGfile = fullfile(EMGfilePath, EMGfileName);

% Read the EMG data
emgData = readtable(EMGfile);

% Normalize the EMG_Flexion and EMG_Extension columns
emgData.EMG_Flexion = emgData.EMG_Flexion / maxMVCFlexion;
emgData.EMG_Extension = emgData.EMG_Extension / maxMVCExtension;

Normalized_EMG_Flexion = emgData.EMG_Flexion;
Normalized_EMG_Extension = emgData.EMG_Extension;

% Pop-up to specify the output file for saving the normalized data
[outputFileName, outputFilePath] = uiputfile(fullfile('C:\Users\AKILAN\Downloads\EMG_DATA\Normalized_data', '*.xlsx'), 'Save Normalized EMG Data As');
outputFile = fullfile(outputFilePath, outputFileName);

% Write the normalized data to the Excel file
writetable(emgData, outputFile);

% Display the max MVC values and confirmation message
fprintf('Max MVC Flexion Value: %.4f\n', maxMVCFlexion);
fprintf('Max MVC Extension Value: %.4f\n', maxMVCExtension);
fprintf('Normalized EMG data saved in %s\n', outputFile);
end