%function Features_batch()

% Define the file path
filePath = 'C:\Users\AKILAN\Downloads\EMG_DATA\processed_data\Processed_EMG_Data_with_FFT.xlsx';

% Read the data from the Excel sheet
data = readtable(filePath);

% Extract the 'Labels', 'EMG_Flexion', and 'EMG_Extension' columns from the table
Labels = data.Labels;
EMG_Flexion = data.EMG_Flexion;
EMG_Extension = data.EMG_Extension;

% Initialize variables for storing batch information
batchStart = 1;
batches = {};
labels = {};
% Initialize storage for all features
rmsValues_Flexion = [];
rmsValues_Extension = [];
wlValues_Flexion = [];
wlValues_Extension = [];
zcValues_Flexion = [];
zcValues_Extension = [];
waValues_Flexion = [];
waValues_Extension = [];
varValues_Flexion = [];
varValues_Extension = [];

% Define a threshold for zero crossing (usually small positive value)
zcThreshold = 0.01;

% Loop through the Labels data to find batches
for i = 2:length(Labels)
    if ~strcmp(Labels{i}, Labels{i-1})  % Detect label change (Flexion/Extension/Rest ends)
        batchEnd = i-1;
        
        % Extract the batch for EMG_Flexion and EMG_Extension
        batch_Flexion = EMG_Flexion(batchStart:batchEnd);
        batch_Extension = EMG_Extension(batchStart:batchEnd);
        
        % --- Calculate Features for Flexion ---
        % RMS
        rmsValue_Flexion = rms(batch_Flexion);
        % Waveform Length
        wlValue_Flexion = sum(abs(diff(batch_Flexion)));
        % Zero Crossings
        zcValue_Flexion = sum(abs(diff(batch_Flexion > zcThreshold)));
        % Willison Amplitude
        waValue_Flexion = sum(abs(diff(batch_Flexion)) > zcThreshold);
        % Variance
        varValue_Flexion = var(batch_Flexion);
        
        % --- Calculate Features for Extension ---
        % RMS
        rmsValue_Extension = rms(batch_Extension);
        % Waveform Length
        wlValue_Extension = sum(abs(diff(batch_Extension)));
        % Zero Crossings
        zcValue_Extension = sum(abs(diff(batch_Extension > zcThreshold)));
        % Willison Amplitude
        waValue_Extension = sum(abs(diff(batch_Extension)) > zcThreshold);
        % Variance
        varValue_Extension = var(batch_Extension);
        
        % Store calculated features
        rmsValues_Flexion = [rmsValues_Flexion; rmsValue_Flexion];
        rmsValues_Extension = [rmsValues_Extension; rmsValue_Extension];
        wlValues_Flexion = [wlValues_Flexion; wlValue_Flexion];
        wlValues_Extension = [wlValues_Extension; wlValue_Extension];
        zcValues_Flexion = [zcValues_Flexion; zcValue_Flexion];
        zcValues_Extension = [zcValues_Extension; zcValue_Extension];
        waValues_Flexion = [waValues_Flexion; waValue_Flexion];
        waValues_Extension = [waValues_Extension; waValue_Extension];
        varValues_Flexion = [varValues_Flexion; varValue_Flexion];
        varValues_Extension = [varValues_Extension; varValue_Extension];
        
        % Store the batch label (Flexion/Extension/Rest)
        labels{end+1} = Labels{batchStart};  
        
        % Move to the next batch
        batchStart = i;  
    elseif i == length(Labels)  % Handle the last batch
        batchEnd = i;
        
        % Extract the batch for EMG_Flexion and EMG_Extension
        batch_Flexion = EMG_Flexion(batchStart:batchEnd);
        batch_Extension = EMG_Extension(batchStart:batchEnd);
        
        % --- Calculate Features for Flexion ---
        % RMS
        rmsValue_Flexion = rms(batch_Flexion);
        % Waveform Length
        wlValue_Flexion = sum(abs(diff(batch_Flexion)));
        % Zero Crossings
        zcValue_Flexion = sum(abs(diff(batch_Flexion > zcThreshold)));
        % Willison Amplitude
        waValue_Flexion = sum(abs(diff(batch_Flexion)) > zcThreshold);
        % Variance
        varValue_Flexion = var(batch_Flexion);
        
        % --- Calculate Features for Extension ---
        % RMS
        rmsValue_Extension = rms(batch_Extension);
        % Waveform Length
        wlValue_Extension = sum(abs(diff(batch_Extension)));
        % Zero Crossings
        zcValue_Extension = sum(abs(diff(batch_Extension > zcThreshold)));
        % Willison Amplitude
        waValue_Extension = sum(abs(diff(batch_Extension)) > zcThreshold);
        % Variance
        varValue_Extension = var(batch_Extension);
        
        % Store calculated features
        rmsValues_Flexion = [rmsValues_Flexion; rmsValue_Flexion];
        rmsValues_Extension = [rmsValues_Extension; rmsValue_Extension];
        wlValues_Flexion = [wlValues_Flexion; wlValue_Flexion];
        wlValues_Extension = [wlValues_Extension; wlValue_Extension];
        zcValues_Flexion = [zcValues_Flexion; zcValue_Flexion];
        zcValues_Extension = [zcValues_Extension; zcValue_Extension];
        waValues_Flexion = [waValues_Flexion; waValue_Flexion];
        waValues_Extension = [waValues_Extension; waValue_Extension];
        varValues_Flexion = [varValues_Flexion; varValue_Flexion];
        varValues_Extension = [varValues_Extension; varValue_Extension];
        
        % Store the batch label
        labels{end+1} = Labels{batchStart};
    end
end

% Create a table to store the results
results = table((1:length(rmsValues_Flexion))', rmsValues_Flexion, rmsValues_Extension, ...
                wlValues_Flexion, wlValues_Extension, zcValues_Flexion, zcValues_Extension, ...
                waValues_Flexion, waValues_Extension, varValues_Flexion, varValues_Extension, ...
                labels', 'VariableNames', {'Batch', 'RMS_Flexion', 'RMS_Extension', ...
                'WL_Flexion', 'WL_Extension', 'ZC_Flexion', 'ZC_Extension', ...
                'WA_Flexion', 'WA_Extension', 'Var_Flexion', 'Var_Extension', 'Label'});

% Display the results
% disp(results);

% Optionally, save the results to an Excel sheet
outputFile = 'C:\Users\AKILAN\Downloads\EMG_DATA\Appended_dataset\batched_EMG.xlsx';
writetable(results, outputFile);

%end