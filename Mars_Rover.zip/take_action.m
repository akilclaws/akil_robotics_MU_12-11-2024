% Function to take action
function [next_state, battery_power] = take_action(state, action, battery_capacity,delta_values,theta_l,theta_h)
    next_state = state;
    battery_power = battery_capacity;
    if action ~= 1 % If action is not to stay
        battery_power = battery_power - (action == 2 || action == 3) * theta_l + (action == 4 || action == 5) * theta_h;
        if battery_power < 0
            battery_power = 0;
        end
        % Implement the logic to update next_state based on action (Up, Down, Left, Right)
        % Update next_state based on the action taken
    end
    % Update battery power based on solar energy gain
    delta = datasample(delta_values, 1);
    battery_power = min(battery_power + delta, battery_capacity);
end