% Define reward function (linearly increasing with distance)
function r = reward(state, grid_size)
    [x, y] = ind2sub([grid_size, grid_size], state);
    start = [1, 1]; % Starting position
    distance = norm([x, y] - start); % Euclidean distance from starting position
    r = distance; % Linearly increasing reward based on distance
end