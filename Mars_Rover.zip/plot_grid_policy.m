function plot_grid_policy(grid_size, policy)
    figure;
    imagesc(reshape(policy, grid_size, grid_size));
    colormap('cool');
    axis off;

    [X,Y] = meshgrid(1:grid_size);
    for i = 1:grid_size
        for j = 1:grid_size
            text(j, i, num2str(policy((i-1)*grid_size + j)), 'HorizontalAlignment', 'center');
        end
    end

    sgtitle('Grid Environment Mapping with Policy Iteration');
end
