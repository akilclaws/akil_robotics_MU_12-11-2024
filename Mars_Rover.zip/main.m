% Define parameters
grid_size = 20;
num_actions = 5; % 0: Stay, 1: Up, 2: Down, 3: Left, 4: Right
num_states = grid_size * grid_size;
alpha = 0.5;
gamma = 0.9;
beta = 0.99; % Discount factor for solar energy gain
battery_capacity = 100;
delta_values = [0, 1, 2]; % Possible values for solar energy gain
theta_l = 0.5; % Low speed battery consumption
theta_h = 0.8; % High speed battery consumption

% Initialize Q table
Q = zeros(num_states, num_actions);
% Value iteration algorithm
V = zeros(num_states, 1);
V_new = zeros(num_states, 1);

for i = 1:1000
    for state = 1:num_states
        for action = 1:num_actions
            next_state = take_action(state, action, battery_capacity, delta_values, theta_l, theta_h);
            reward_val = reward(next_state, grid_size);
            
            % Calculate discounted reward considering both gamma and beta
            discounted_reward = reward_val + beta * gamma * V(next_state);
            
            % Update Q-value using the discounted reward
            Q(state, action) = alpha * discounted_reward;
        end
    end
    % Update V using the maximum Q-value for each state
    V = max(Q, [], 2);
end

% Policy iteration algorithm
policy = zeros(num_states, 1); % Initialize policy
for i = 1:1000
    for state = 1:num_states
        max_q_value = 30;
        best_action = 0; % Initialize best action for current state
        for action = 1:num_actions
            % Calculate Q-value for the action
            next_state = take_action(state, action, battery_capacity, delta_values, theta_l, theta_h);
            reward_val = reward(next_state, grid_size);
            q_val = reward_val + beta * gamma * V(next_state);
            
            % Update the best action and its Q-value
            if q_val > max_q_value
                max_q_value = q_val;
                best_action = action;
            end
        end
        % Update policy for the current state
        policy(state) = best_action;
    end
end

plot_grid_policy(grid_size, policy);