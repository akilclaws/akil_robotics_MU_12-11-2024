clc;
clear all;
close all;

x = 0.25;
y = 0.25;
l1 = 0.5;
l2 = 0.5;
l3 = 0.5;

si = 60;
P_2x = x - l3*cosd(si);
P_2y = y - l3*sind(si);

    cos_theta2 = (P_2x^2 + P_2y^2 - l1^2 - l2^2) / (2 * l1 * l2);
    sin_theta2 = sqrt(1 - cos_theta2^2);
    theta2 = atan2d(sin_theta2, cos_theta2);

    alpha = atan2d(P_2y, P_2x);
    beta = atan2d(l2 * sin(theta2), l1 + l2 * cos(theta2));
    theta1 = alpha - beta;

    theta3 = si - theta1 - theta2;

    % Plotting the manipulator
    plot([0, l1*cosd(theta1)], [0, l1*sind(theta1)], 'o-', 'LineWidth', 2); hold on;
    plot([l1*cosd(theta1), P_2x], [l1*sind(theta1), P_2y], 'o-', 'LineWidth', 2);
    plot([P_2x, x], [P_2y, y], 'o-', 'LineWidth', 2);
    plot(x, y, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r'); % End-effector point

    % Plot the vector from origin to end-effector
    quiver(P_2x, P_2y, 0.5, 0.866, 'b', 'LineWidth', 0.5, 'MaxHeadSize', 0.5);

    % Plot the angle arc
    radius = 0.05; % Adjust the radius of the arc as needed
    angle = atan2(l3*sind(theta1+theta2+theta3),l3*cosd(theta1+theta2+theta3));

    % Annotate the angle in words
    angle_degrees = rad2deg(angle);
    angle_text = sprintf('%.2f degrees', angle_degrees);
    text(l3*sind(theta1+theta2+theta3)/2, l3*cosd(theta1+theta2+theta3)/2, angle_text, 'HorizontalAlignment', 'center');

    % Customize plot
    axis equal;
    xlim([-l1 - l2, l1 + l2]);
    ylim([-l1 - l2, l1 + l2]);
    title('Three-Link Manipulator Inverse Kinematics');
    xlabel('X-axis');
    ylabel('Y-axis');
    grid on;
    hold off;
