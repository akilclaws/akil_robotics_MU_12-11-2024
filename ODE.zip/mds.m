function funval = mds(t,x)

%% Properties of System %%
c = 1; %% Damping  (If C = 0 imploes undamped system)
k = 15; %% Stiffness
m = 10; %% Mass

%% zeta = (c/(2*sqrt(k*m)) -  play with c, k and m to create different zeta values (like zeta = 0 or 1 or >1)

%% Initial Conditions %%
xp = x(1); %% x(1) implies Position data
v = x(2);  %% x(2) implies velocity data

%% ODE Evaluation %%
funval(1,1) = v; %% First line integrates velocity to arrive at position
funval(2,1) = -(c*v + k*xp)/m; %% First line integrates position to arrive at velocity

end