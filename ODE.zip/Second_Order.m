clc;
clear;

%% Spring - Mass - Damper System - 2nd Order Differential Equation 
%% Initial condition %%
x0 = [1;0];   % Value 1 = Position (X =1 @ t=0); Value 2 = Velocity (x_dot = 0 @ t=0) 

%% Time Spna
tspan = 0:0.1:10; %% Solving for 10 seconds 

%% ODE Solver %%
[tsol,xsol]=ode45(@(t,x) mds(t,x), tspan,x0);
% tsols the time data (seconds)
% xsol - two dimensional vector, first column holds position data and
% second column holds velocity data

%% Plotting Figure %%
figure;
plot(tsol,xsol(:,1),'LineWidth',2,'Color','r'); %% Plotting position data 
hold on;
plot(tsol,xsol(:,2),'LineWidth',2,'Color','b'); %% Plotting velocity data 
legend('Positon','Velocity');
grid on; grid minor;
xlabel('Time (S)');
set(gca,'FontSize',20);