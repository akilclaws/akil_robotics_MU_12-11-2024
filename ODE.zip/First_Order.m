clc;
clear;

y0 = 2 ; %% Initial condition - y = 2 @ x=0; 
%tspan = 0:0.5:10; %% This line if we want to have contrl on step size
Xspan = 0:10; %% ALgoritm decides the step size based on the complexity.


[xval,yval] = ode45(@(x,y) ODESO(x,y), Xspan,y0); %% Calling ODE SOlver

% xval holds the value of X 
% yval - one dimensional vector that holds the function values for all xval

%% Plotting Figure
figure;
plot(xval,yval,'r','LineWidth',2);
xlabel('X'); ylabel('Y');
grid on; grid minor;
set(gca,'FontSize',15);

%% Function for ODE solver
function funval = ODESO(x,y)
funval = 4*exp(0.8*x) - 0.5*y; %% Differential equation that is to be solved
end




